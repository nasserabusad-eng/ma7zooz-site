/* محظوظ — embed reliability helper
   These arcade games are third-party iframes (GameMonetize). Ad-blockers and
   in-app browsers (Instagram/TikTok/Facebook webviews) frequently block the
   game host, leaving a blank frame. This gives the visitor a clear message and
   an "open in browser" escape hatch instead of a silent blank box. */
(function () {
  var frame = document.getElementById('frame');
  if (!frame) return;
  var iframe = frame.querySelector('iframe');
  var fb = document.getElementById('embedFallback');

  // Point every external-open link at the game's own URL.
  var src = iframe ? iframe.getAttribute('src') : '';
  Array.prototype.forEach.call(document.querySelectorAll('.js-open-external'), function (a) {
    if (src) a.setAttribute('href', src);
  });

  var loaded = false;
  if (iframe) {
    iframe.addEventListener('load', function () {
      loaded = true;
      if (fb) fb.hidden = true;
    });
  }

  // If the frame never loads (request blocked upstream), reveal the fallback.
  setTimeout(function () {
    if (!loaded && fb) fb.hidden = false;
  }, 9000);
})();
